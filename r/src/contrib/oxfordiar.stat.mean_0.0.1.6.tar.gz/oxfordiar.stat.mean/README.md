# `oxfordiar.stat.mean`

Mean statistic queries for Oxfordia R.

`ox_mean()` calculates federated means across one or more targets. It accepts a
data shortcut or a full graph path. It does not accept shortcut names as plain
strings.

## Install

Install from the Oxfordia R repository (not CRAN; no clone needed):

```r
install.packages(
  c("solidauthr", "oxfordiar", "oxfordiar.data.nemaline", "oxfordiar.stat.mean"),
  repos = c(
    oxfordia = "https://oxfordia-project.github.io/OXFORDIA-node/r",
    CRAN = "https://cloud.r-project.org"
  )
)
```

See the [`oxfordiar` install instructions](../oxfordiar/README.md#install) for
the full package set, release tarballs and installing from a local clone.

## Quick Start

```r
library(oxfordiar)
library(oxfordiar.data.nemaline)
library(oxfordiar.stat.mean)

result <- ox_mean(
  shortcut = ox_nemaline_shortcut("BaselineAge"),
  targets = ox_targets(
    ox_target("site_a", "https://pod.example.org/alice/data.ttl")
  )
)

result$data
```

`ox_mean()` returns an `ox_result_set`. `result$data` contains the overall mean,
and `result$by_target` keeps the individual per-target mean/count data frames.

## API

### `ox_mean(shortcut, targets, auth = oxfordiar::ox_auth_none(), fail_fast = TRUE)`

Arguments:

- `shortcut`: an `ox_data_shortcut` or `ox_graph_path`
- `targets`: one or more `ox_target()` objects
- `auth`: default authentication configuration
- `fail_fast`: if `TRUE`, stop on the first target error; if `FALSE`, collect
  target errors in `result$errors`

Behavior:

- `shortcut` may be a shortcut object from a data package such as
  `ox_nemaline_shortcut("BaselineAge")`
- `shortcut` may also be a manually constructed `ox_graph_path()`
- plain strings such as `"BaselineAge"` are rejected on purpose

### Return Value

`ox_mean()` returns an `ox_result_set` list with:

- `data`: one-row data frame containing the overall federated mean and count
- `by_target`: named list of successful per-target mean/count data frames
- `errors`: data frame of target errors when `fail_fast = FALSE`
- `responses`: raw successful request/response entries
- `route`, `statistic`, `fields`, `targets`: query metadata

`result$data` is a data frame with these columns:

- `mean`
- `count`

Each entry in `result$by_target` is a data frame with these columns:

- `target`
- `resource_uri`
- `statistic`
- `mean`
- `count`

## Grouping

Pass `group_by` (one shortcut, or a list of two) to break the result down,
for example by causative gene, or by gene and gender:

```r
result <- ox_mean(
  ox_nemaline_shortcut("BaselineAge"),
  targets = targets,
  group_by = list(
    ox_nemaline_shortcut("CausativeGene"),
    ox_nemaline_shortcut("GenderAssignedAtBirth")
  )
)
```

`result$data` has one row per group: a column per group-by (named after the
shortcut, holding the label), the combined statistic, `sites` (targets that
reported the group) and `suppressed_sites` (targets that withheld it because
it fell below their minimum count; such combined values are partial).
`result$per_site` has the same rows for each target. Each group-by must be
allowed for the shortcut by the target's statistic access rule.

## Examples

### Mean Over a Nemaline Shortcut

```r
library(oxfordiar)
library(oxfordiar.data.nemaline)
library(oxfordiar.stat.mean)

targets <- ox_targets(
  ox_target("site_a", "https://pod.example.org/alice/data.ttl"),
  ox_target("site_b", "https://pod.example.org/bob/data.ttl")
)

result <- ox_mean(
  shortcut = ox_nemaline_shortcut("BaselineAge"),
  targets = targets
)

result$data
result$by_target
```

### Mean Over a Manual Graph Path

```r
library(oxfordiar)
library(oxfordiar.stat.mean)

path <- ox_graph_path(
  start = ox_node_filter(
    predicates = list(
      ox_predicate_filter(
        "http://www.w3.org/1999/02/22-rdf-syntax-ns#type",
        some = ox_node_selector(
          ox_node_filter(
            iri = "https://w3id.org/semanticarts/ns/ontology/gist/Person"
          )
        )
      )
    )
  )
)

result <- ox_mean(
  shortcut = path,
  targets = ox_targets(
    ox_target("site_a", "https://pod.example.org/alice/data.ttl")
  )
)

result$data
```

### Collect Per-Target Errors Instead of Failing Fast

```r
result <- ox_mean(
  shortcut = ox_nemaline_shortcut("BaselineAge"),
  targets = ox_targets(
    ox_target("site_a", "https://pod.example.org/alice/data.ttl"),
    ox_target("site_b", "https://pod.example.org/bob/data.ttl")
  ),
  fail_fast = FALSE
)

result$data
result$errors
```

### Use Default Auth and Target-Specific Auth

```r
result <- ox_mean(
  shortcut = ox_nemaline_shortcut("BaselineAge"),
  targets = ox_targets(
    ox_target(
      name = "site_a",
      resource_uri = "https://pod.example.org/alice/data.ttl",
      auth = ox_auth_bearer("site-a-token")
    )
  ),
  auth = ox_auth_solid(
    issuer = "https://solid-idp.example.org",
    client_id = Sys.getenv("SOLID_CLIENT_ID"),
    client_secret = Sys.getenv("SOLID_CLIENT_SECRET")
  )
)
```
